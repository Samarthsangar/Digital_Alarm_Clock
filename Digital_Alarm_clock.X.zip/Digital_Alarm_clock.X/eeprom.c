#include <xc.h>

#include "main.h"
#include "external_eeprom.h"
#include "i2c.h"

/*Function to write in extrenal EEPROM address*/
void write_external_eeprom(unsigned char address, unsigned char data)
{
    /*I2C protocol function call*/
    i2c_start();
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
    for (unsigned int wait = 3000;wait--;);
}

/*Function to read from extrenal EEPROM address*/
unsigned char read_external_eeprom(unsigned char address)
{
    unsigned char data;
    /*I2C protocol function call*/
    i2c_start();
    /*First writing SLAVE ID then reading*/
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address);
    i2c_rep_start();
    i2c_write(SLAVE_READ_E);
    data = i2c_read();
    i2c_stop();

    return data;
}
