/***********************************************DIGITAL ALARM CLOCK*************************************************************/
/*
 * Name : Samarth Rajendra Sangar.
 * Date : 19/11/2024
 * Project Name : Digital Alarm Clock.
 *                This project give user friendly interface as well as ability to
 *                set time & date Also set Alarm & view alarms & also set alarm one's ,daily 
 *                & weekly And delete also. In this project single key worked as a edge & level 
 *                triggering.RTC & I2C protocol give synchronously data TX & RX.
 */
#include <xc.h>                                      //Header file include
#include "main.h"
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "matrix_keypad.h"
#include "isr.h"
#include "external_eeprom.h"

unsigned char clock_reg[3];                         //clock array for time 
unsigned char calender_reg[4];                      //calender array for date
unsigned char time[6];                              //array to store 1-1 byte data of time
unsigned char Event[7]={48,48,48,48,48,48,48};      //Event array to save & fetch saved event's
unsigned char date[11];                             //array to store 1-1 byte data of Date
unsigned int sec,Select_flag=1,index_Flag=0,Display_Flag=0,Week_flag=0,Ones_flag=0,Day_flag=0;      //flag's for condition checking
unsigned char key,backup,backup1;                   
unsigned int Address[]={0x00,0x07,0x14};            //array for address to storing & fetching data from particular location

int SET_EVENT()                             //function to set event's
{
    Display_Flag=0;
    sec=0;
    unsigned int Mode=0,arrow_flag=1;      //set flag for condition checking
    CLEAR_DISP_SCREEN;
    if(index_Flag>=3)                      //check flag to check space available or not to store event's
    {                                      //print information for user & return 0;
        clcd_print("NO SPACE TO    ",LINE1(0));
        clcd_print(" ADD EVENT'S :(",LINE1(0));
        for(unsigned long int delay=10000; delay--; );
        sec=0;
        Display_Flag=0;
        CLEAR_DISP_SCREEN;                  //clear the display
        return 0;
    }
    while(1)                                //continuous while loop
    {
            clcd_print("TIME ",LINE1(0));   //first line print the current time
            clcd_putch(' ',LINE1(10));
            clcd_print(time,LINE1(5));
            
            if(Display_Flag==0)             //check flag & store data into event flag 6 position
                Event[6]='O';
            else if(Display_Flag==1)
                Event[6]='D';
            else
                Event[6]='W';
            
            if(arrow_flag==1)               //arrow flag for the arrow character print
                clcd_putch(0x91,LINE1(15));
            else
                clcd_putch(0x81,LINE1(15));
            
            if (clock_reg[0] & 0x40)        //check condition & print it is PM or AM
            {
                if (clock_reg[0] & 0x20)
                {
                    clcd_print("PM    ", LINE1(11));
                }
                else
                {
                    clcd_print("AM    ", LINE1(11));
                }
            }
            
            clcd_print("DUR - ",LINE2(0));              //print second line duration
            if(Mode==0)                                 //initial hour field blinking to set alarm
            {
                if(sec%2==0)
                {
                    clcd_putch(Event[0],LINE2(6));
                    clcd_putch(Event[1],LINE2(7));
                }
                else
                {
                    clcd_putch(' ',LINE2(6));
                    clcd_putch(' ',LINE2(7));
                }
                clcd_putch(Event[2],LINE2(9));
                clcd_putch(Event[3],LINE2(10));
                clcd_putch(Event[4],LINE2(12));
                clcd_putch(Event[5],LINE2(13));
                clcd_putch(Event[6],LINE2(15));
            }
            clcd_putch(':',LINE2(8));
            if(Mode==1)                                     //based on mode flag blinking minute field
            {
                if(sec%2==0)
                {
                    clcd_putch(Event[2],LINE2(9));
                    clcd_putch(Event[3],LINE2(10));
                }
                else
                {
                    clcd_putch(' ',LINE2(9));
                    clcd_putch(' ',LINE2(10));
                }
                clcd_putch(Event[0],LINE2(6));
                clcd_putch(Event[1],LINE2(7));
                clcd_putch(Event[4],LINE2(12));
                clcd_putch(Event[5],LINE2(13));
                clcd_putch(Event[6],LINE2(15));
            }
            clcd_putch(' ',LINE2(11));
            if(Mode==2)                                     //based on mode flag blinking AM/PM field
            {
                if(sec%2==0)
                {
                    clcd_putch(Event[4],LINE2(12));
                    clcd_putch(Event[5],LINE2(13));
                }
                else
                {
                    clcd_putch(' ',LINE2(12));
                    clcd_putch(' ',LINE2(13));
                }
                clcd_putch(Event[0],LINE2(6));
                clcd_putch(Event[1],LINE2(7));
                clcd_putch(Event[2],LINE2(9));
                clcd_putch(Event[3],LINE2(10));
                clcd_putch(Event[6],LINE2(15));
            }
            clcd_putch(' ',LINE2(14));
            key = read_switches(STATE_CHANGE);                      //check switch pressed condition
            if(key==MK_SW1)                             //if SW1 for upside move & also set alarm             
            {
                for(sec=0; sec<=3;)                     //loop for checking long pressed SW1 for 3 sec
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW1 && sec==3)           //if true then save alarm on particular address location
                    {
                        unsigned int add=Address[Display_Flag];
                        for(int i=0; i<7; i++)
                            write_external_eeprom(add++,Event[i]);
                        if(Display_Flag>=0)
                            Ones_flag=1;
                        if(Display_Flag>=1)
                        {
                            backup1=read_ds1307(DAY_ADDR);
                            Day_flag=1;
                        }
                        if(Display_Flag>=2)
                        {
                            backup=read_ds1307(DAY_ADDR);
                            Week_flag=1;
                        }
                        sec=0;
                        Display_Flag=0;
                        index_Flag++;
                        CLEAR_DISP_SCREEN;
                        return 1;                        //return 1 for go main menu after save alarm
                    }
                    else if(key!=MK_SW1)                //if short pressed then break this long pressed search loop immediately
                    {
                        sec=0;
                        break;
                    }
                }
                Display_Flag--;                         //decrease flag & check Condition for limited decrement
                if(Display_Flag<=0 || Display_Flag>=5)
                {
                    Display_Flag=0;
                    arrow_flag=2;
                }
            }
            else if(key==MK_SW2)                            //if SW2 for downside move & also go to previous dashboard    
            {
                for(sec=0; sec<=3;)                         //loop for checking long pressed SW2 for 3 sec
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW2 && sec==3)               //if true then goto previous dashboard with return 0;
                    {
                        sec=0;
                        Display_Flag=0;
                        CLEAR_DISP_SCREEN;
                        return 0;
                    }
                    else if(key!=MK_SW2)                    //if short pressed then break this long pressed search loop immediately
                    {
                        sec=0;
                        break;
                    }
                }
                Display_Flag++;                         //increase flag & check Condition for limited increment
                if(Display_Flag>=2)
                {
                    Display_Flag=2;
                    arrow_flag=1;
                }
            }
            else if(key==MK_SW3)                        //SW3 for change blinking field
            {
                Mode++;
                if(Mode>2)
                    Mode=0;
            }
            else if(key==MK_SW4)                        //SW4 for particular field data increase only
            {
                if(Mode==0)                             //Mode 0 for hour field
                {
                    if(Event[0]>='2' && Event[1]>='3')
                    {
                        Event[0]='0';
                        Event[1]='0';
                    }
                    else if(((Event[1])++)>='9')
                    {
                        Event[1]='0';
                        Event[0]++;
                    }
                }
                else if(Mode==1)                                //Mode 0 for Minute field
                {
                    if(Event[2]=='5' && Event[3]>='9')
                    {
                        Event[2]='0';
                        Event[3]='0';
                    }
                    else if(((Event[3])++)>='9')
                    {
                        Event[3]='0';
                        Event[2]++;
                    }
                }
                else if(Mode==2)                            //Mode 0 for AM/PM field
                {
                    if(Event[4]=='P' && Event[5]=='M')
                    {
                        Event[4]='A';
                        Event[5]='M';
                    }
                    else
                    {
                        Event[4]='P';
                        Event[5]='M';
                    }
                }
            }
        }
}

int SET_VIEW()                              //function to view set alarms
{
    Display_Flag=0;                         //first set all flag's
    sec=0;
    unsigned int arrow_flag=1;
    CLEAR_DISP_SCREEN;
    unsigned int add=Address[Display_Flag];
    if(index_Flag>0)                                //check any alarm set or not otherwise print 0 in view alarm
    {
        for(int i=0; i<7; i++)
            Event[i]=read_external_eeprom(add++);
    }
    while(1)                                      //continuous while loop
    {
        clcd_print("# T - ",LINE1(0));            //first line print current time 
        clcd_putch(' ',LINE1(10));
        clcd_print(time,LINE1(6));
            if (clock_reg[0] & 0x40)              //check condition to print PM or AM
            {
                if (clock_reg[0] & 0x20)
                {
                    clcd_print("PM   ", LINE1(12));
                }
                else
                {
                    clcd_print("AM   ", LINE1(12));
                }
            }
        if(Display_Flag>=index_Flag)                //check condition for set limits
             Display_Flag=0;
        
        if(Display_Flag==0)                         //based on flag value store event flag O,D or W
            Event[6]='O';
        else if(Display_Flag==1)
            Event[6]='D';
        else
            Event[6]='W';
            
        if(arrow_flag==1)                           //check flag for arrow printing
            clcd_putch(0x19,LINE1(15));
        else
            clcd_putch(0x18,LINE1(15));
        
        clcd_putch(Display_Flag+48,LINE2(0));       //display the set alarms
        clcd_print(" D - ",LINE2(1));
        clcd_putch(Event[0],LINE2(6));
        clcd_putch(Event[1],LINE2(7));
        clcd_putch(':',LINE2(8));
        clcd_putch(Event[2],LINE2(9));
        clcd_putch(Event[3],LINE2(10));
        clcd_putch(' ',LINE2(11));
        clcd_putch(Event[4],LINE2(12));
        clcd_putch(Event[5],LINE2(13));
        clcd_putch(' ',LINE2(14));
        clcd_putch(Event[6],LINE2(15));
        
        key = read_switches(STATE_CHANGE);              //check switch pressed status
            if(key==MK_SW1)                             //SW1 for upside move & long pressed for delete all alarms
            {
                for(sec=0; sec<=3;)                     //check SW1 long pressed 3 sec or not
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW1 && sec==3)               //if true then delete all alarms means clear flag's
                    {
                        clcd_print("DELATING ALL    ",LINE1(0));
                        clcd_print("ALARM'S WAIT :( ",LINE2(1));
                        for(unsigned int delay=10000; delay--; );
                        sec=0;
                        Display_Flag=0;
                        index_Flag=0;
                        Week_flag=0;
                        Ones_flag=0;
                        Day_flag=0;
                        if(index_Flag>=5)
                            index_Flag=0;
                        CLEAR_DISP_SCREEN;
                        return 1;
                    }
                    else if(key!=MK_SW1)                        //if not then break loop
                    {
                        sec=0;
                        break;
                    }
                }
                Display_Flag--;                         //decrement value & check condition for limit
                if(Display_Flag<=0 || Display_Flag>=5)
                {
                    Display_Flag=0;
                    arrow_flag=2;
                }
                add=Address[Display_Flag];              //based on flag read event's stored on particular address
                for(int i=0; i<7; i++)
                    Event[i]=read_external_eeprom(add++);
            }
            else if(key==MK_SW2)                        //SW2 for move downside
            {
                for(sec=0; sec<=3;)                     //SW2 for downside move & long pressed for go to previous dashboard
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW2 && sec==3)           //check SW2 long pressed 3 sec or not
                    {
                        sec=0;                          //if true then return to previous dashboard
                        Display_Flag=0;
                        CLEAR_DISP_SCREEN;
                        return 0;
                    }
                    else if(key!=MK_SW2)                //if not then break loop
                    {
                        sec=0;
                        break;
                    }
                }
                Display_Flag++;                         //increment value & check condition for limit
                if(Display_Flag>=index_Flag)
                {
                    Display_Flag=index_Flag-1;
                    arrow_flag=1;
                }
                add=Address[Display_Flag];              //based on flag read event's stored on particular address
                for(int i=0; i<7; i++)
                    Event[i]=read_external_eeprom(add++);
            }
    }
}

int SET_DATE()                              //function to set date
{
    sec=0;
    unsigned int i=0,j=0,k=0,Mode=0;
    while(1)                                //continuous loop
    {
        if(i>=32)                           //based on condition limit the variables
            i=0;
        else if(j>=13)
            j=0;
        else if(k>=100)
            k=0;
        
        clcd_print("     DD-MM-YY    ",LINE1(0));           //print first line prompt
        clcd_print("     ",LINE2(0));
        clcd_putch(':',LINE2(7));
        clcd_putch(':',LINE2(10));
        clcd_print("    ",LINE2(13));
        if(Mode==0)                                 //mode 0 then blink the Day field for change
        {
            if(sec%2==0)
            {
                clcd_putch((i%10)+48,LINE2(6));
                clcd_putch(((i/10)%10)+48,LINE2(5));
            }
            else
            {
                clcd_putch(' ',LINE2(5));
                clcd_putch(' ',LINE2(6));
            }
            clcd_putch((j%10)+48,LINE2(9));
            clcd_putch(((j/10)%10)+48,LINE2(8));
            clcd_putch((k%10)+48,LINE2(12));
            clcd_putch(((k/10)%10)+48,LINE2(11));
        }
        else if(Mode==1)                                //mode 1 then blink the Month field for change
        {
            if(sec%2==0)
            {
                clcd_putch((j%10)+48,LINE2(9));
                clcd_putch(((j/10)%10)+48,LINE2(8));
            }
            else
            {
                clcd_putch(' ',LINE2(8));
                clcd_putch(' ',LINE2(9));
            }
            clcd_putch((i%10)+48,LINE2(6));
            clcd_putch(((i/10)%10)+48,LINE2(5));
            clcd_putch((k%10)+48,LINE2(12));
            clcd_putch(((k/10)%10)+48,LINE2(11));
        }
        else if(Mode==2)                                    //mode 2 then blink the Year field for change
        {
            if(sec%2==0)
            {
                clcd_putch((k%10)+48,LINE2(12));
                clcd_putch(((k/10)%10)+48,LINE2(11));
            }
            else
            {
                clcd_putch(' ',LINE2(11));
                clcd_putch(' ',LINE2(12));
            }
            clcd_putch((i%10)+48,LINE2(6));
            clcd_putch(((i/10)%10)+48,LINE2(5));
            clcd_putch((j%10)+48,LINE2(9));
            clcd_putch(((j/10)%10)+48,LINE2(8));
        }
        key = read_switches(STATE_CHANGE);                 //check the status of switch pressed
            if(key==MK_SW1)                     //SW1 for increment & long pressed for three sec to save
            {
                for(sec=0; sec<=3;)             //check SW1 is pressed for 3 sec or not
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW1 && sec==3)               //if true then save the date
                    {
                        write_ds1307(DATE_ADDR,((((i/10))<<4)|((i%10))));
                        write_ds1307(MONTH_ADDR,((((j/10))<<4)|((j%10))));
                        write_ds1307(YEAR_ADDR,((((k/10))<<4)|((k%10))));
                        sec=0;
                        CLEAR_DISP_SCREEN;
                        return 1;
                    }
                    else if(key!=MK_SW1)                    //else break the loop
                    {
                        sec=0;
                        break;
                    }
                }
                if(Mode==0)                         //based on mode increment particular variable value
                    i++;
                else if(Mode==1)
                    j++;
                else
                    k++;
            }
            else if(key==MK_SW2)                    //SW2 for decrement & long pressed for three sec to go previous dashboard
            {
                for(sec=0; sec<=3;)                 //check SW2 is pressed for 3 sec or not
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW2 && sec==3)           //if true then return 0 & goto previous dashboard
                    {
                        CLEAR_DISP_SCREEN;
                        return 0;
                    }
                    else if(key!=MK_SW2)       //else break the loop
                    {
                        sec=0;
                        break;
                    }
                }
                if(Mode==0)             //based on mode decrement particular variable value
                    i--;
                else if(Mode==1)
                    j--;
                else
                    k--;
            }
            else if(key==MK_SW3)        //SW3 for change field
            {
                Mode++;
                if(Mode>=3)
                    Mode=0;
            }
    }
}

int SET_TIME()                      //function to set time
{
    sec=0;
    unsigned int i=0,j=0,k=0,Mode=0;
    while(1)                        //continuous loop
    {
        if(i>=24)                   //limit the variable values
            i=0;
        else if(j>=60)
            j=0;
        else if(k>=60)
            k=0;
        
        clcd_print("     HH:MM:SS    ",LINE1(0));       //print hour,minute & sec for user prompt
        clcd_print("     ",LINE2(0));
        clcd_putch(':',LINE2(7));
        clcd_putch(':',LINE2(10));
        clcd_print("    ",LINE2(13));
        if(Mode==0)                             //mode 0 for blinking the hour field
        {
            if(sec%2==0)
            {
                clcd_putch((i%10)+48,LINE2(6));
                clcd_putch(((i/10)%10)+48,LINE2(5));
            }
            else
            {
                clcd_putch(' ',LINE2(5));
                clcd_putch(' ',LINE2(6));
            }
            clcd_putch((j%10)+48,LINE2(9));
            clcd_putch(((j/10)%10)+48,LINE2(8));
            clcd_putch((k%10)+48,LINE2(12));
            clcd_putch(((k/10)%10)+48,LINE2(11));
        }
        else if(Mode==1)                                //mode 1 for blinking the minute field
        {
            if(sec%2==0)
            {
                clcd_putch((j%10)+48,LINE2(9));
                clcd_putch(((j/10)%10)+48,LINE2(8));
            }
            else
            {
                clcd_putch(' ',LINE2(8));
                clcd_putch(' ',LINE2(9));
            }
            clcd_putch((i%10)+48,LINE2(6));
            clcd_putch(((i/10)%10)+48,LINE2(5));
            clcd_putch((k%10)+48,LINE2(12));
            clcd_putch(((k/10)%10)+48,LINE2(11));
        }
        else if(Mode==2)                            //mode 2 for blinking the sec field
        {
            if(sec%2==0)
            {
                clcd_putch((k%10)+48,LINE2(12));
                clcd_putch(((k/10)%10)+48,LINE2(11));
            }
            else
            {
                clcd_putch(' ',LINE2(11));
                clcd_putch(' ',LINE2(12));
            }
            clcd_putch((i%10)+48,LINE2(6));
            clcd_putch(((i/10)%10)+48,LINE2(5));
            clcd_putch((j%10)+48,LINE2(9));
            clcd_putch(((j/10)%10)+48,LINE2(8));
        }
        key = read_switches(STATE_CHANGE);              //check the status of switch pressed
            if(key==MK_SW1)                     //SW1 for increment value & long pressed for save time
            {
                for(sec=0; sec<=3;)             //run loop & check SW1 is long pressed on not
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW1 && sec==3)           //if true then save time & goto main dashboard
                    {
                        write_ds1307(HOUR_ADDR,((((i/10))<<4)|((i%10))));
                        write_ds1307(MIN_ADDR,((((j/10))<<4)|((j%10))));
                        write_ds1307(SEC_ADDR,((((k/10))<<4)|((k%10))));
                        sec=0;
                        CLEAR_DISP_SCREEN;
                        return 1;
                    }
                    else if(key!=MK_SW1)                //if false then break the loop
                    {
                        sec=0;
                        break;
                    }
                }
                if(Mode==0)                     //based on mode value increment the count value
                    i++;
                else if(Mode==1)
                    j++;
                else
                    k++;
            }
            else if(key==MK_SW2)                //SW2 for decrement value & long pressed for goto previous dashboard
            {
                for(sec=0; sec<=3;)             //run loop & check SW2 is long pressed on not
                {
                    key = read_switches(LEVEL_CHANGE);
                    if(key==MK_SW2 && sec==3)       //if true then without save goto previous dashboard
                    {
                        CLEAR_DISP_SCREEN;
                        return 0;
                    }
                    else if(key!=MK_SW2)            //if false then break the loop
                    {
                        sec=0;
                        break;
                    }
                }
                if(Mode==0)                         //based on mode value decrement the count value
                    i--;
                else if(Mode==1)
                    j--;
                else
                    k--;
            }
            else if(key==MK_SW3)                    //switch 3 for change mode
            {
                Mode++;
                if(Mode>=3)
                    Mode=0;
            }
    }
}

int SET_VIEW_EVENT()                        //function to call set or view event individually
{
    unsigned short Select_flag=1;
    sec=0;
    CLEAR_DISP_SCREEN;
    while(1)                                //continuous loop
    {
        if(Select_flag==1)                  //based on select flag print *
        {
            clcd_print("* ",LINE1(0));
            clcd_print("  ",LINE2(0));
        }
        else
        {
            clcd_print("  ",LINE1(0));
            clcd_print("* ",LINE2(0));
        }
        clcd_print("SET EVENT     ",LINE1(2));          //print prompt to user
        clcd_print("VIEW EVENT    ",LINE2(2));
        key = read_switches(STATE_CHANGE);              //read matrix keypad switches status
        if(key==MK_SW1)                                 //long pressed of SW1 for enter into particular event
        {            
            for(sec=0; sec<=3;)                         //loop for checking SW1 is long or not
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW1 && sec==3)
                {
                    if(Select_flag==1)                  //if true then enter into particular event
                    {
                        if(SET_EVENT()==1)
                        {
                            sec=0;
                            return 1;
                        }
                    }
                    else
                    {
                        if(SET_VIEW()==1)
                        {
                            sec=0;
                            return 1;
                        }
                    }
                    break;
                }
                else if(key!=MK_SW1)                    //else break the loop
                {
                    sec=0;
                    break;
                }
            }
            Select_flag--;                      //short press move upside *
            if(Select_flag<=1)
                Select_flag=1;
        }
        else if(key==MK_SW2)                    //SW2 for move down side & goto previous dashboard
        {
            for(sec=0; sec<=3;)                 //loop to check status of SW2 is long pressed or not
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW2 && sec==3)           //if yes then return to previous dashboard
                {
                    sec=0;
                    CLEAR_DISP_SCREEN;
                    return 0;
                }
                else if(key!=MK_SW2)
                {
                    sec=0;
                    break;
                }
            }
             Select_flag++;                     //for short press move * downside
            if(Select_flag>=2)
                Select_flag=2;
            
        }
    }
    sec=0;
    CLEAR_DISP_SCREEN;
    return 0;
}

int SET_TIME_DATE()                      //function to call set time or date event individually
{
    unsigned short Select_flag=1;
    sec=0;
    CLEAR_DISP_SCREEN;
    while(1)                            //continuous loop
    {
        if(Select_flag==1)              //based on select flag print *
        {
            clcd_print("* ",LINE1(0));
            clcd_print("  ",LINE2(0));
        }
        else
        {
            clcd_print("  ",LINE1(0));
            clcd_print("* ",LINE2(0));
        }
        clcd_print("SET DATE       ",LINE1(2));         //print prompt to user
        clcd_print("SET TIME       ",LINE2(2));
        key = read_switches(STATE_CHANGE);              //read matrix keypad switches status
        if(key==MK_SW1)                             //long pressed of SW1 for enter into particular event
        {
            for(sec=0; sec<=3;)                     //loop for checking SW1 is long or not
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW1 && sec==3)           //if true then enter into particular event
                {
                    if(Select_flag==1)
                    {
                        if(SET_DATE()==1)
                        {
                            sec=0;
                            CLEAR_DISP_SCREEN;
                            return 1;
                        }
                    }
                    else
                    {
                        if(SET_TIME()==1)
                        {
                            sec=0;
                            CLEAR_DISP_SCREEN;
                            return 1;
                        }
                    }
                    break;
                }
                else if(key!=MK_SW1)                    //else break the loop
                {
                    sec=0;
                    break;
                }
            }
            Select_flag--;                          //short press move upside *
            if(Select_flag<=1)
                Select_flag=1;
            
        }
        else if(key==MK_SW2)                        //SW2 for move down side & goto previous dashboard
        {
            for(sec=0; sec<=3;)                     //loop to check status of SW2 is long pressed or not
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW2 && sec==3)           //if yes then return to previous dashboard
                {
                    sec=0;
                    CLEAR_DISP_SCREEN;
                    return 0;
                }
                else if(key!=MK_SW2)                //else break the loop
                {
                    sec=0;
                    break;
                }
            }
            Select_flag++;                  //short press move downside *
            if(Select_flag>=2)
                Select_flag=2;
            
        }
    }
    sec=0;
    CLEAR_DISP_SCREEN;
}
void Menu_Bar()                        //function to display menu dashboard
{
    Select_flag=1;
    sec=0;
    CLEAR_DISP_SCREEN;
    while(sec<=4)                       //only for 5 sec if user not do any action goto main dashboard
    {
        if(Select_flag==1)              //based on flag value display the *
        {
            clcd_print("* ",LINE1(0));
            clcd_print("  ",LINE2(0));
        }
        else
        {
            clcd_print("  ",LINE1(0));
            clcd_print("* ",LINE2(0));
        }
        clcd_print("SET DATE/TIME ",LINE2(2));
        clcd_print("SET/VIEW EVENT",LINE1(2));
        
        key = read_switches(STATE_CHANGE);              //read the status of switch pressed
        if(key==MK_SW1)                                 //SW1 is for the enter into particular event & move upside also               
        {            
            for(sec=0; sec<=3;)                         //check SW1 is long pressed or not 
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW1 && sec==3)               //if true then enter into particular event
                {
                    if(Select_flag==1)
                    {
                        if(SET_VIEW_EVENT()==1)
                        {
                            sec=0;
                            return;
                        }
                    }
                    else
                    {
                        if(SET_TIME_DATE()==1)
                        {
                            sec=0;
                            return;
                        }
                    }                    
                    break;
                }
                else if(key!=MK_SW1)                //else break the loop
                {
                    sec=0;
                    break;
                }
            }
             Select_flag--;                 //on short pressed move upside *
            if(Select_flag<=1)
                Select_flag=1;
        }
        else if(key==MK_SW2)            //SW2 is for the move particular event & move downside also based on SW pressed
        {
            for(sec=0; sec<=3;)         //check SW2 is long pressed or not 
            {
                key = read_switches(LEVEL_CHANGE);
                if(key==MK_SW1 && sec==3)           //if true then enter into particular event
                {
                    if(Select_flag==1)
                    {
                        if(SET_VIEW_EVENT()==1)
                        {
                            sec=0;
                            return;
                        }
                    }
                    else
                    {
                        if(SET_TIME_DATE()==1)
                        {
                            sec=0;
                            return;
                        }
                    }
                    break;
                }
                else if(key!=MK_SW2)                        //else break the loop
                {
                    sec=0;
                    break;
                }
            }
             Select_flag++;                                 //on short pressed move upside *
            if(Select_flag>=2)
                Select_flag=2;
        }
    }
    sec=0;
    CLEAR_DISP_SCREEN;
}

void Main_display()                             //main dashboard function
{
    get_time();                                 //get time function call
    get_date();                                 //get date function call
    if(sec<=4)                                  //display date & time for 5 sec
    {
        clcd_print("DATE ",LINE1(0));
        clcd_print(date,LINE1(5));
        clcd_print("TIME ",LINE2(0));
        clcd_putch(' ',LINE2(10));
        clcd_print(time,LINE2(5));
        clcd_print("      ", LINE2(11));
        if (clock_reg[0] & 0x40)                    //condition to print AM / PM
        {
            if (clock_reg[0] & 0x20)
            {
                clcd_print("PM    ", LINE2(11));
            }
            else
            {
                clcd_print("AM    ", LINE2(11));
            }
        }
    }
    else                                        //else for every 2 sec print set alarm time
    {
        clcd_print("TIME ",LINE1(0));
        clcd_putch(' ',LINE1(10));
        clcd_print(time,LINE1(5));
        clcd_print("       ",LINE1(10));
        if (clock_reg[0] & 0x40)
        {
            if (clock_reg[0] & 0x20)
            {
                clcd_print("PM    ", LINE1(11));
            }
            else
            {
                clcd_print("AM    ", LINE1(11));
            }
        }
        if(index_Flag!=0)                           //based on index flag compare event are present or not
        {
            if(Display_Flag==index_Flag)
                Display_Flag=0;
            
            unsigned int add=Address[Display_Flag++];
            for(int i=0; i<7; i++)
                Event[i]=read_external_eeprom(add++);
            
            clcd_print("EVENT ",LINE2(0));
            clcd_putch(Event[0],LINE2(6));
            clcd_putch(Event[1],LINE2(7));
            clcd_putch(':',LINE2(8));
            clcd_putch(Event[2],LINE2(9));
            clcd_putch(Event[3],LINE2(10));
            clcd_putch(' ',LINE2(11));
            clcd_putch(Event[4],LINE2(12));
            clcd_putch(Event[5],LINE2(13));
            clcd_putch(' ',LINE2(14));
            clcd_putch(Event[6],LINE2(15));
        }
        else 
        {
            clcd_print("EVENT ",LINE2(0));
            clcd_putch(' ',LINE2(11));
            clcd_print("--:-- ",LINE2(6));
            clcd_print("-- -",LINE2(12));
        }
    }
}

int Check_timer()                       //function to compare set alarm & current time
{
    Display_Flag=0;
    unsigned int add;
    for(int j=0; j<index_Flag; j++)     //run loop based on flag
    {
        get_time();
        add=Address[Display_Flag++];        //fetch data from EEPROM
        for(int i=0; i<7; i++)
            Event[i]=read_external_eeprom(add++);
        if(Event[0]==time[0] && Event[1]==time[1] && Event[2]==time[3] && Event[3]==time[4] && Ones_flag==1 && Event[6]=='O')
        {                               //check condition for ones timer 
            Ones_flag=0;
            if(clock_reg[0] & 0x20)
            {
                if(Event[4]=='P' && Event[5]=='M')
                    return 1;
            }
            else
            {
                if(Event[4]=='A' && Event[5]=='M')
                    return 1;
            }
        }
        else if(Event[0]==time[0] && Event[1]==time[1] && Event[2]==time[3] && Event[3]==time[4] && Day_flag==1 && Event[6]=='D')
        {                                   //check condition for daily timer
            Day_flag=0;
            backup1+=1;
            if(backup1>=0x32)               //condition flag/backup flag for daily
                backup1=0x05;
            if(clock_reg[0] & 0x20)
            {
                if(Event[4]=='P' && Event[5]=='M')
                    return 1;
            }
            else
            {
                if(Event[4]=='A' && Event[5]=='M')
                    return 1;
            }
        }
        else if(Event[0]==time[0] && Event[1]==time[1] && Event[2]==time[3] && Event[3]==time[4] && Week_flag==1 && Event[6]=='W')
        {                               //check condition for weekly timer
            Week_flag=0;
            backup=read_ds1307(DAY_ADDR);           //condition flag/backup flag for weekly 
            backup+=7;
            if(backup>=0x32)
                backup=0x06;
            if(clock_reg[0] & 0x20)
            {
                if(Event[4]=='P' && Event[5]=='M')
                    return 1;
            }
            else
            {
                if(Event[4]=='A' && Event[5]=='M')
                    return 1;
            }
        }
    }
    Display_Flag=0;
    return 0;
}

static void get_time(void)                  //function to get time
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);      //goto particular address & fetch data & store into array
	clock_reg[1] = read_ds1307(MIN_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = '\0';
}

static void get_date(void)                           //function to get date
{
	calender_reg[0] = read_ds1307(YEAR_ADDR);        //goto particular address & fetch data & store into array
	calender_reg[1] = read_ds1307(MONTH_ADDR);
	calender_reg[2] = read_ds1307(DATE_ADDR);
	calender_reg[3] = read_ds1307(DAY_ADDR);
    if(backup==calender_reg[3])
        Week_flag=1;
    else if(backup1==calender_reg[3])
        Day_flag=1;
	date[0] = '2';
	date[1] = '0';
	date[2] = '0' + ((calender_reg[0] >> 4) & 0x0F);
	date[3] = '0' + (calender_reg[0] & 0x0F);
	date[4] = '-';
	date[5] = '0' + ((calender_reg[1] >> 4) & 0x0F);
	date[6] = '0' + (calender_reg[1] & 0x0F);
	date[7] = '-';
	date[8] = '0' + ((calender_reg[2] >> 4) & 0x0F);
	date[9] = '0' + (calender_reg[2] & 0x0F);
	date[10] = '\0';
}

/*Called function for initial configuration*/
static void init_config(void)
{
    /*Function call for CLCD initial configuration*/
    init_clcd();
    init_i2c();
	init_ds1307();
    init_matrix_keypad();
    
    /*Setting 8 bit timer register*/
	T08BIT = 1;

/* Selecting internal clock source */
	T0CS = 0;

/* Enabling timer0*/
	TMR0ON = 1;

/* disabling prescaler*/
	PSA = 1;

	TMR0 = 6;

	/* Clearing timer0 overflow interrupt flag bit */
	TMR0IF = 0;

	/* Enabling timer0 overflow interrupt */
	TMR0IE = 1;
    
    /* Enabling Buzzer */
    TRISE0 = 0;
    
    RE0 = 0;
     /*Enable peripheral interrupt enable*/
    PEIE = 1;
    /*Enable global interrupt enable*/
    GIE = 1;
    
}

void main(void)                     //main function
{
    /*Function call for initial configuration*/
    init_config();
        
    while (1)                       //continuous while super loop
    {
        key = read_switches(STATE_CHANGE);      //read the status of switches
        if(Check_timer()==1)            //function call & based on return value on buzzer
        {
            RE0=1;
            while(1)                    //loop to continuous on buzzer
            {
                key = read_switches(STATE_CHANGE);
                if(key==MK_SW1)
                {
                    RE0=0;
                    break;
                }
            }
        }
        Main_display();                 //function call to display main dashboard
        
        if(key==MK_SW1 || key==MK_SW2)      //based on switch pressed inter into menu dashboard
                Menu_Bar();
          
        
    }
}