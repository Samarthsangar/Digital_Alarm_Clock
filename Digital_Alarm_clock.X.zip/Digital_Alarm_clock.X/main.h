/* 
 * File:   main.h
 * Author: samar
 *
 * Created on 11 November, 2024, 12:28 PM
 */

#ifndef MAIN_H
#define	MAIN_H

static void get_time(void);
static void get_date(void);
void Menu_Bar();
void Main_display();
int SET_VIEW_EVENT();
int SET_TIME_DATE();
int SET_EVENT();
int SET_DATE();
int SET_VIEW();
int SET_TIME();
int Check_timer();

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

